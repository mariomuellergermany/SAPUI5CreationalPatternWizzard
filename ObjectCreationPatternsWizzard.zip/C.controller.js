sap.ui.define([
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/Label',
	'sap/m/MessageToast',
	'sap/m/Text',
	'sap/m/TextArea',
	'sap/ui/core/mvc/Controller',
	'sap/ui/layout/HorizontalLayout',
	'sap/ui/layout/VerticalLayout'
], function (Button, Dialog, Label, MessageToast, Text, TextArea, Controller, HorizontalLayout, VerticalLayout) {
	"use strict";

	var CController = Controller.extend("sap.m.sample.DialogConfirm.C", {

		onInit: function () {
			//this.byId("textAreaContent").setValue("uschi");
			var cacheTextarea = this.byId("textAreaContent");
			cacheTextarea.setValue("classname:cars" + "\n" + "attribute:color" + "\n" + "attribute:maxSpeed");
			console.log(cacheTextarea);
		},
		//############################
		// onClassNameDialog
		//###########################
		onClassNameDialog: function (oEvent) {
			var textareaCache = this.byId("textAreaContent");

			var dialog = new Dialog({
				title: 'Enter the name of the class you want wo create',
				type: 'Message',
				content: [
					new Label({
						text: '',
						labelFor: 'usersDecisionForClassname'
					}),
					new TextArea('usersDecisionForClassname', {
						width: '100%',
						placeholder: 'Add classname'
					})
				],
				beginButton: new Button({
					text: 'Create',
					press: function (oEvent) {
						var sText = "classname:" + sap.ui.getCore().byId('usersDecisionForClassname').getValue();

						textareaCache.setValue(textareaCache.getValue() + "\n" + sText);
						dialog.close();
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});

			dialog.open();
		},
		//############################
		// onAddAttibuteDialog
		//###########################
		onAddAttibuteDialog: function () {
			var textareaCache = this.byId("textAreaContent");

			var dialog = new Dialog({
				title: 'Enter a class attribute (e.g. age, name, weight)',
				type: 'Message',
				content: [
					new Label({
						text: '',
						labelFor: 'textarea'
					}),
					new TextArea('textarea', {
						width: '100%',
						placeholder: 'Add attribute'
					})
				],
				beginButton: new Button({
					text: 'create',
					press: function () {
						var sText = "attribute:" +
							sap.ui.getCore().byId('textarea').getValue();
						//MessageToast.show('Note is: ' + sText);
						textareaCache.setValue(textareaCache.getValue() + "\n" + sText);
						dialog.close();
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});

			dialog.open();
		},
		//############################
		// onGenerateCodingDialog
		// https://www.youtube.com/watch?v=xizFJHKHdHw&t=633s
		//###########################
		onGenerateCodingDialog: function () {

			// get content of textarea (user input) into variables 
			var textareaCache = this.byId("textAreaContent");
			var textareaArray = textareaCache.getValue().split(/[\n]+/);
			// get into variables
			var textAreaGeneratedCodingCache = this.byId("textAreaGeneratedCoding");
			var generatedCoding = "";
			var className = "";

			// find the classname
			for (var i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("classname:")) {
					className = textareaArray[i].substring(10) + "Constructor";
					break;

				}
				console.log(textareaArray[i]);
			}
			generatedCoding = "var " + className + "=function(";

			// loop to get attributes to detemine how many attributes
			var attrCount = 0;
			for (var i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					attrCount++;
				}
				console.log(textareaArray[i]);
			}
			//loop attributes to generate coding
			var attrCountTmp = attrCount;
			for (var i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					attrCountTmp--;
					if (attrCountTmp == 0) {
						generatedCoding = generatedCoding + textareaArray[i].substring(10);
					} else {
						generatedCoding = generatedCoding + textareaArray[i].substring(10) + ", ";
					}
				}
			}
			generatedCoding = generatedCoding + ") {" + "\n\n";

			//loop attributes to generate coding: this-rows 
			for (var i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					var attribute = textareaArray[i].substring(10);
					generatedCoding = generatedCoding + "this." +
						textareaArray[i].substring(10) + " = " + attribute + ";\n";
				}
			}

			// generate "print-function" >>>
			generatedCoding = generatedCoding + "\nthis.print = function(){";
			generatedCoding = generatedCoding + "\nconsole.log(";
			attrCountTmp = attrCount;
			for (i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					attribute = textareaArray[i].substring(10);

					attrCountTmp--;
					if (attrCountTmp === 0) {
						generatedCoding = generatedCoding + "this." + attribute + ");";
					} else {
						generatedCoding = generatedCoding + "this." + attribute + '+ ",  " + ';
					}

				}
			}
			generatedCoding = generatedCoding + "\n};";
			// generate "print-function" <<<
			generatedCoding = generatedCoding + "\n};";

			// fenerate an example
			generatedCoding = generatedCoding + "\n\n//example how to call the pattern:\n";
			var example = "var myInstance = new " + className + "(";
			//loop attributes 
			attrCountTmp = attrCount;
			for (i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					attrCountTmp--;
					if (attrCountTmp === 0) {
						example = example + "'" + i + "');";
					} else {
						example = example + "'" + i + "',";
					}
				}
			}
			example = example + "myInstance.print();";
			textAreaGeneratedCodingCache.setValue(generatedCoding + example);
		},
		//############################
		// onGenerateCodingDialog
		// https://www.youtube.com/watch?v=xizFJHKHdHw&t=633s
		//###########################
		onGeneratePrototypeCodingDialog: function () {

			// get content of textarea (user input) into variables 
			var textareaCache = this.byId("textAreaContent");
			var textareaArray = textareaCache.getValue().split(/[\n]+/);
			// get into variables
			var textAreaGeneratedPrototypeCoding = this.byId("textAreaGeneratedPrototypeCoding");
			var generatedCoding = "";
			var className = "";

			// find the classname
			for (var i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("classname:")) {
					className = textareaArray[i].substring(10) + "Prototype";
					break;

				}
				console.log(textareaArray[i]);
			}
			generatedCoding = "var " + className + "=function(";

			// loop to get attributes to detemine how many attributes
			var attrCount = 0;
			for (i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					attrCount++;
				}
				console.log(textareaArray[i]);
			}

			generatedCoding = generatedCoding + ") {" + "\n\n";

			//loop attributes to generate coding: this-rows 
			for (i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					generatedCoding = generatedCoding + className + "." + "prototype." +
						textareaArray[i].substring(10) + " = " + '"place default value here"' + ";\n";

				}
			}
			generatedCoding = generatedCoding + "\n";
			generatedCoding = generatedCoding + className + ".prototype.print = function() {";
			generatedCoding = generatedCoding + "console.log(";

			//loop attributes to generate coding
			var attrCountTmp = attrCount;
			for (i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					attrCountTmp--;
					var attribute = textareaArray[i].substring(10);
					if (attrCountTmp === 0) {
						generatedCoding = generatedCoding + "this." + attribute;
					} else {
						generatedCoding = generatedCoding + "this." + attribute + '+ ", " ' + "+";

					}

				}
			}
			generatedCoding = generatedCoding + ");\n\n};";

			generatedCoding = generatedCoding + "\n};\n\n//example how to call the pattern:\n";
			var example = "var myInstance = new " + className + "();\n";
			//loop attributes 
			attrCountTmp = attrCount;
			for (i = 0; i < textareaArray.length; i++) {
				if (textareaArray[i].startsWith("attribute:")) {
					attrCountTmp--;
					example = example + "myInstance" + "." + textareaArray[i].substring(10) + ' = "YourValue";' + "\n";

				}
			}
			example = example + "myInstance.print();";
			textAreaGeneratedPrototypeCoding.setValue(generatedCoding + example);
		}
	});

	return CController;

});